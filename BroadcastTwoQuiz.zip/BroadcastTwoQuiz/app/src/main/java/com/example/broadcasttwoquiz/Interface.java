package com.example.broadcasttwoquiz;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Interface extends AppCompatActivity {

    private TextView tvCharging;
    private TextView tvInternet;
    private View rootLayout;

    private boolean isCharging = false;
    private boolean isInternetConnected = false;

    private final BroadcastReceiver chargingReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || intent.getAction() == null) {
                return;
            }

            boolean bothWereOnBefore = isCharging && isInternetConnected;
            String action = intent.getAction();

            if (Intent.ACTION_POWER_CONNECTED.equals(action)) {
                isCharging = true;
                tvCharging.setText("Charging: ON");
                Toast.makeText(context, "Charging!", Toast.LENGTH_SHORT).show();

            } else if (Intent.ACTION_POWER_DISCONNECTED.equals(action)) {
                isCharging = false;
                tvCharging.setText("Charging: OFF");
                Toast.makeText(context, "Charging stopped!", Toast.LENGTH_SHORT).show();
            }

            if (!bothWereOnBefore && isCharging && isInternetConnected) {
                Toast.makeText(context, "Charging and connected to internet!", Toast.LENGTH_LONG).show();
            }

            updateBackgroundColor();
        }
    };

    private final BroadcastReceiver internetReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean bothWereOnBefore = isCharging && isInternetConnected;
            boolean previousInternetState = isInternetConnected;

            isInternetConnected = checkInternetConnection();
            tvInternet.setText("Internet: " + (isInternetConnected ? "ON" : "OFF"));

            if (!previousInternetState && isInternetConnected) {
                Toast.makeText(context, "Internet connected!", Toast.LENGTH_SHORT).show();
            } else if (previousInternetState && !isInternetConnected) {
                Toast.makeText(context, "Internet disconnected!", Toast.LENGTH_LONG).show();
            }

            if (!bothWereOnBefore && isCharging && isInternetConnected) {
                Toast.makeText(context, "Charging and connected to internet!", Toast.LENGTH_LONG).show();
            }

            updateBackgroundColor();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_interface);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.activity_interface), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        rootLayout = findViewById(R.id.activity_interface);
        tvCharging = findViewById(R.id.tvChargingStatus);
        tvInternet = findViewById(R.id.tvInternetStatus);

        setInitialBatteryState();
        isInternetConnected = checkInternetConnection();
        tvInternet.setText("Internet: " + (isInternetConnected ? "ON" : "OFF"));

        updateBackgroundColor();
    }

    @Override
    protected void onStart() {
        super.onStart();

        IntentFilter chargingFilter = new IntentFilter();
        chargingFilter.addAction(Intent.ACTION_POWER_CONNECTED);
        chargingFilter.addAction(Intent.ACTION_POWER_DISCONNECTED);
        registerReceiver(chargingReceiver, chargingFilter);

        IntentFilter internetFilter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(internetReceiver, internetFilter);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(chargingReceiver);
        unregisterReceiver(internetReceiver);
    }

    private void setInitialBatteryState() {
        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, ifilter);

        if (batteryStatus != null) {
            int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING
                    || status == BatteryManager.BATTERY_STATUS_FULL;
        } else {
            isCharging = false;
        }

        tvCharging.setText("Charging: " + (isCharging ? "ON" : "OFF"));
    }

    private boolean checkInternetConnection() {
        ConnectivityManager connectivityManager =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connectivityManager == null) {
            return false;
        }

        Network network = connectivityManager.getActiveNetwork();
        if (network == null) {
            return false;
        }

        NetworkCapabilities capabilities =
                connectivityManager.getNetworkCapabilities(network);

        return capabilities != null &&
                (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                        || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                        || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
    }

    private void updateBackgroundColor() {
        if (isCharging && isInternetConnected) {
            rootLayout.setBackgroundColor(getColor(android.R.color.holo_green_light));
        } else if (isCharging || isInternetConnected) {
            rootLayout.setBackgroundColor(getColor(android.R.color.holo_orange_light));
        } else {
            rootLayout.setBackgroundColor(getColor(android.R.color.holo_red_light));
        }
    }
}